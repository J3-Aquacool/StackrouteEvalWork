

public class Country 
{
private String countryname;
@Override
public String toString() {
	return "Country [countryname=" + countryname + ", population=" + population
			+ "]";
}
public String getCountryname() {
	return countryname;
}
public void setCountryname(String countryname) {
	this.countryname = countryname;
}
public long getPopulation() {
	return population;
}


public void setPopulation(long population) 
{
	this.population = population;
}

public Country(String countryname, long population)
{
	super();
	this.countryname = countryname;
	this.population = population;
}

private long population;


}
