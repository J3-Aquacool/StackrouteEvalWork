
public class MainApp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

PopulationAPI p=new PopulationAPI();
p.provideInfo();
	
	
	}

}
