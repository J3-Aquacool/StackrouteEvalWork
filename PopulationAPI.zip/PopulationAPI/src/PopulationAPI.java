import static com.jayway.restassured.RestAssured.get;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.stream.Collectors;

import org.json.JSONArray;
import org.json.JSONObject;




import com.jayway.restassured.response.Response;


public class PopulationAPI
{


	private static String url;
    private static int count;
    //private static int sCode;
    


public void provideInfo()
{
		
		
	try        {
        url = "http://restcountries.eu/rest/v1/all";

        // make get request to fetch json response from restcountries            
	   Response resp = get(url);

        //Fetching response in JSON as a string then convert to JSON Array            
	   JSONArray jsonResponse = new JSONArray(resp.asString());
	      
//	   System.out.print(jsonResponse);
       
	   
	   count = jsonResponse.length(); // how many items in the array
	   
	   List<Country> cdata=new ArrayList();
	   for (int it = 0; it < count; it++) {
           JSONObject contactItem =jsonResponse.getJSONObject(it);
           
           String country = contactItem.getString("name");
           //String population = contactItem.getString("population");
           Long  population = contactItem.getLong("population");

           cdata.add(new Country(country,population));
           
       //    System.out.println("Country Name-->" + country+"||Population-->"+population);
       }
	   
	   /*System.out.println(cdata);
	   
	   Iterator <Country> it=cdata.iterator();
	   while(it.hasNext())
	   {
		   
		   Country c=it.next();
		   System.out.println(c.getCountryname() +"||" +c.getPopulation());
	   }

	   System.out.println("Print with STreams");
	   
	   cdata.stream().forEach((condata)->System.out.println(cdata));
	   
*/	   

	   //Sortby population
	   cdata.stream().sorted(Comparator.comparingLong(Country::getPopulation)).collect(Collectors.toList()).forEach(cname->System.out.println(cname.getPopulation()  +" ||"+cname.getCountryname()));
	   //Sortby Country Name
	   cdata.stream().sorted(Comparator.comparing(Country::getCountryname)).collect(Collectors.toList()).forEach(cname->System.out.println(cname.getCountryname() + "  ||     "+cname.getPopulation()));
	   
	   
	   
	   
	   
	   
	   
	   /*
	   sCode = resp.statusCode();  // status code of 200
	   */
	   //create new arraylist to match CountriesData            
	   /*List<CountriesData> cDataList = new ArrayList<CountriesData>();
	   
	   //System.out.print(cDataList);

        Gson gson = new Gson();
        Type listType = new TypeToken<List<CountriesData>>() {}.getType();

        cDataList = gson.fromJson(jsonResponse.toString(), listType);
        

        cList = cDataList;
*/
     }
     catch (Exception e)
     {
         System.out.println("There is an error connecting to the API: " + e);
         e.getStackTrace();
     }
 }



}

	
	



